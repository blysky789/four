import sqlite3 as sql3
import aiogram
import asyncio
import logging
from aiogram import Bot, Dispatcher, F
from aiogram.types import Message
from typing import List
from asyncpg import Record
from core.settings import settings

mybot = Bot(token=settings.bots.mybot_token)
dp = Dispatcher(mybot = mybot)

async def one(dp):
        logging.basicConfig(level = logging.INFO,
                format="%(asctime)s - [%(levelname)s] - %(name)s -"
                "(%(filename)s).%(funcName)s.%(lineno)d) - %(message)s")
        dp.message.register(stepone, F.text=='d')

        await dp.start_polling(mybot)

async def two():
        a = 4
        b = 32.25
        c = 30.02
        db = sql3.connect('first_base.db')
        cur = db.cursor()
        # id_bank = 1
        # buy = 83.55
        # sale = 88.88
        # cur.execute(f"insert into ptable values ({id_bank}, {buy}, {sale}) "\
        #      f" on conflict (id_bank) "\
        #      f"do update set id_bank  = excluded.id_bank, buy = excluded.buy, sale = excluded.sale;" )
        # cur.execute(f"insert into ptable values ({a}, {b}, {c}) on conflict (id_bank) do nothing")
        print('succesful')
        db.commit()
        c = await addallusers()
        print(c)


async def stepone(message: Message):
        await message.answer('Nigga')
        await addallusers()
        
async def addallusers():

        db = sql3.connect('first_base.db')
        cur = db.cursor()
        buy = 'buy'
        id_bank = 1
        # cur.execute(f"insert into sender values ({id}, {every}, {time}, '{status}') on conflict (id) do nothing") 
        a = cur.execute(f'select {buy} from ptable where id_bank = {id_bank};').fetchall()
        # db.commit()
        b = str(a[0])
        b1 = float(b[1:-2])
        c =  float('{:.1f}'.format(b1))
        db.commit()
        return c



async def three():
        a = await addallusers()
        print(a)

async def start(dp):
        task1 = asyncio.create_task(one(dp))
        task2 = asyncio.create_task(two())
        # task3 = asyncio.create_task(three())
        await task1
        await task2
        # await task3
                    

if __name__ == "__main__":
        asyncio.run(start(dp))
       