import asyncio
import logging
import asyncpg
from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command
from aiogram.types import Message, ContentType, CallbackQuery, InlineKeyboardButton
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from core.handlers import base
from core.settings import settings
from core.utils.states import Steps
from core.middleware.mwdbconnect import DbSession 
from core.utils.dbconnect import DbRequests
from core.handlers.base import every_module, time_module
from core.handlers.base import switch
from core.handlers.base import create_pool


mybot = Bot(token=settings.bots.mybot_token)
dp = Dispatcher(mybot = mybot)
switch = 'sql'

filelogger = logging.FileHandler('my_log.log', mode='w')
filelogger.setLevel(logging.DEBUG)
filelogger_info = logging.FileHandler('my_log_info.log', mode='w')
filelogger_info.setLevel(logging.INFO)
form = '%(asctime)s : %(name)s : %(levelname)s : %(message)s' 
logging.basicConfig(level='DEBUG', format=form, handlers=[filelogger, filelogger_info])
logger = logging.getLogger(__name__)


# async def create_pool():
#         return await asyncpg.create_pool(user='r2admin', password='admin@123', database='sender', 
#                         host='127.0.0.1', port='5432', command_timeout='60')

async def one(dp):
        global switch
        logger.debug('switch def one() == %s', switch)
        if switch == 'psql':
                pool_connect = await create_pool()
                dp.update.middleware.register(DbSession(pool_connect))
        # dp.message.register(get_start, Command(commands='start'))
        dp.message.register(base.get_start, F.text=='d')
        dp.callback_query.register(base.get_sender, Steps.get_sender)
        dp.message.register(base.get_time, Steps.get_time)

        await dp.start_polling(mybot)

async def two(mybot): # <---- schedule module
        # pool_connect = await create_pool()
        scheduler = AsyncIOScheduler()
        # request = DbRequests(pool_connect)
        scheduler.add_job(every_module, 'interval', seconds=20, args=(mybot,))
        scheduler.add_job(time_module, 'cron', hour='0-23', minute='05', args=(mybot,))
        scheduler.start()

async def start(dp, mybot):
        logger.info('START SCRIPT')
        task1 = asyncio.create_task(one(dp))
        task2 = asyncio.create_task(two(mybot))
        await task1
        await task2

if __name__ == "__main__":
        asyncio.run(start(dp, mybot))

        
        
        