import requests
import json
import asyncio
import logging
from bs4 import BeautifulSoup


pb_url = 'https://api.privatbank.ua/p24api/pubinfo?json&exchange&coursid=5' 
nbu_url = 'https://bank.gov.ua/NBUStatService/v1/statdirectory/exchange?json'
sens_url = 'https://sensebank.ua/currency-exchange'

res_nbu: float = []
res_pb: float = []
res_sens: float = []

filelogger = logging.FileHandler('my_log.log', mode='w')
filelogger.setLevel(logging.DEBUG)
filelogger_info = logging.FileHandler('my_log_info.log', mode='w')
filelogger_info.setLevel(logging.INFO)
form = '%(asctime)s : %(name)s : %(levelname)s : %(message)s' 
logging.basicConfig(level='DEBUG', format=form, handlers=[filelogger, filelogger_info])
logger = logging.getLogger(__name__)


#Parsing requests
async def get_res_nbu():
    global nbu_url
    global res_nbu
    try:    
        req = requests.get(nbu_url)
    except Exception as e:
        logger.info(f'ERROR NBU request %s', e)
    re = req.json()[24]['rate']
    r = float('{:.1f}'.format(re))
    get_res_nbu_buy: float = r
    get_res_nbu_sale: float = r
    get_res_nbu = [get_res_nbu_buy, get_res_nbu_sale]
    res_nbu = get_res_nbu
    return res_nbu
            
async def get_res_pb():
    global pb_url
    global res_pb
    try:
        req = requests.get(pb_url)
    except Exception as e:
        logger.info(f'ERROR PB request %s', e)
    re_buy = float(req.json()[1]['buy'])
    re_sale = float(req.json()[1]['sale'])
    r_buy = float('{:.1f}'.format(re_buy))
    r_sale = float('{:.1f}'.format(re_sale))
    get_res_pb_buy: float = float(r_buy)
    get_res_pb_sale: float = float(r_sale)
    get_res_pb = [get_res_pb_buy, get_res_pb_sale]
    res_pb = get_res_pb
    return res_pb
                      
async def get_res_sens():
    global sens_url
    global res_sens
    try:
        req = requests.get(sens_url)
    except Exception as e:
        logger.info(f'ERROR SENS request %s', e)
    soup = BeautifulSoup(req.text, 'lxml')
    a = soup.find_all('h3', class_= "exchange-rate-tabs__info-value h4")
    b = str(a)
    c = b.split()
    re_buy = float(c[3])
    re_sale = float(c[8])
    r_buy = float('{:.1f}'.format(re_buy))
    r_sale = float('{:.1f}'.format(re_sale))
    get_res_sens_buy: float = float(r_buy)
    get_res_sens_sale: float = float(r_sale)
    get_res_sens = [get_res_sens_buy, get_res_sens_sale]
    res_sens = get_res_sens
    return res_sens












