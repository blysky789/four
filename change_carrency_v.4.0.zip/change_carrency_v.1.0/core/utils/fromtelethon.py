import asyncio
import aiogram
import logging
from aiogram import Bot, Dispatcher
from telethon import TelegramClient
from telethon.tl import functions, types
import json
# from ..settings import settings

api_id = 28291766
api_hash = '6fbbceea3f490599490e2ea7be468414'

filelogger = logging.FileHandler('my_log.log', mode='w')
filelogger.setLevel(logging.DEBUG)
filelogger_info = logging.FileHandler('my_log_info.log', mode='w')
filelogger_info.setLevel(logging.INFO)
form = '%(asctime)s : %(name)s : %(levelname)s : %(message)s' 
logging.basicConfig(level='DEBUG', format=form, handlers=[filelogger, filelogger_info])
logger = logging.getLogger(__name__)

async def get_res_point():
    try:
        client = TelegramClient('dodik', api_id, api_hash)
        await client.start()
        channel = 'Obmenkaakh'
        print('work')
        channel_to = await client.get_entity(channel)
        messages = await client.get_messages(channel_to, limit= 1)
        await asyncio.sleep(0.1)
    except Exception as e:
        logger.info(f'ERROR telethon request %s', e)

    for x in messages:
        a = x.text
    
    c = a.split()
    # print(c)
    count = 0
    for d in c:
        count += 1
        if d == '🇺🇸USD':
             f = c[count]
             f1 = float(f[:-14])
             f2 = float(f[6:-8])
             k1 = float('{:.1f}'.format(f1))
             k2 = float('{:.1f}'.format(f2))        
        # if d == '🇪🇺EUR':
        #      f3 = c[count][:-2]
        #      f4 = c[count+1][:-1]
    await client.disconnect()
    return [k1, k2]

   
    
